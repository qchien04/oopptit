package Bai27;

public class MonHoc {
	private String maMon;
	private String tenMon;
	
	public MonHoc() {
		this.maMon = "";
		this.tenMon = "";
	}
	public MonHoc(String maMon, String tenMon) {
		
		this.maMon = maMon;
		this.tenMon = tenMon;
	}
	
}
